# KubeUpgrade Guardian - Overleaf package

This package is rebuilt from the uploaded LaTeX source `kubeupgrade-guardian-readiness(4).tex`.

What was changed:

- Original structure and experimental results preserved.
- RQ3 reframed from `Actionability` to `Structural Plan Completeness`.
- Three TikZ figures rebuilt and resized safely for two-column IEEE layout.
- Figure 3 corrected as a clear controlled-evaluation pipeline.
- Pluto/kubent kept as specialized API-deprecation baselines, not general baselines.
- R10 wording corrected: false negatives expose implementation gaps but do not prove oracle independence.
- AIOps keyword removed; LLM/agent discussion reframed as evidence-bounded operations assistance.
- Additional official Kubernetes, AKS, Gatekeeper, and Kyverno references added.
- References are embedded in `main.tex`; no external `.bib` is required.

Compile `main.tex` in Overleaf with pdfLaTeX.
